package com.forneron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerieTvApplicationTests {

	@Test
	void contextLoads() {
	}

}
