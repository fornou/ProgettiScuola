let age = 19, maximumAge = 27, numberOfCoffePerDay = 1, daysInYear = 365

let daysToMyDie = maximumAge - age
let numberOfTotalCoffe = numberOfCoffePerDay * (daysInYear*daysToMyDie)

console.log("You will need "+ numberOfTotalCoffe +" cups of coffee to last you until the ripe old age of "+ maximumAge)

