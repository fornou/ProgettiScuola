let celsiusTemp = 30

let farhaineitTemp = (celsiusTemp * 9/5) + 32 

console.log(celsiusTemp +"°C is "+farhaineitTemp+"°F")

farhaineitTemp = 140

celsiusTemp = (farhaineitTemp - 32) * 5/9

console.log(farhaineitTemp +"°F is "+celsiusTemp+"°C")