let numberOfChildren =  4, partnerName = "Sofia", jobTitle = "backend developer", geoLocation = "Berlin"

console.log("You will be a "+ jobTitle +" in "+ geoLocation +", and married to "+ partnerName +" with "+ numberOfChildren +" kids.")