let radius = 2, pi = 3.14

circunference = 2*pi*radius
area = pi*(Math.pow(radius,2))

console.log("The circumference is "+ circunference)

console.log("The area is "+ area)