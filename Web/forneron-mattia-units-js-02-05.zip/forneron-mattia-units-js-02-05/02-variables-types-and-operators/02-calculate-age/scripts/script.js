let myBirthYear = 2004
let futureYear = 2014

let age = futureYear - myBirthYear
let age2 = age - 1

console.log("I will be either "+ age +" or "+ age2 +" in " + futureYear)